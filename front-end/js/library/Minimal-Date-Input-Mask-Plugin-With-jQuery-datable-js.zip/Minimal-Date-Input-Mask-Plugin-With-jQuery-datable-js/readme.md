## About

datable.js is a lightweight, customizable, bootstraps-friendly jQuery plugin to properly format dates in inputs and verify that the date is valid.


## Demo

View the [demo](http://invot.github.io/datable.js/) for instructions!
